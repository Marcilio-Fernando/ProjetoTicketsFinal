﻿using GestorTickets.Desktop.Pages; 
using System.Windows;

namespace GestorTickets.Desktop
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Define o conteúdo inicial do Frame
            MainFrame.Content = new PgFuncionarios();
        }

        // Métodos acionados pelos botões no XAML para navegação

        private void Navigate_Funcionarios(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PgFuncionarios());
        }

        private void Navigate_Tickets(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PgTickets());
        }

        private void Navigate_Relatorios(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PgRelatorios());
        }

        private void Navigate_Sair(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}