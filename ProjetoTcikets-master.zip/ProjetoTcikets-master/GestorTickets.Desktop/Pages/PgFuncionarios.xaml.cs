﻿using System.Windows;
using System.Windows.Controls;
using GestorTicketsRefeicao.Services;
using GestorTicketsRefeicao.Models;
using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Reports;
using System;
using System.Windows.Media;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Input; 

namespace GestorTickets.Desktop.Pages
{
    public partial class PgFuncionarios : Page
    {
        private readonly FuncionarioService _funcionarioService;
        private Funcionarios? _funcionarioEmEdicao;

        public PgFuncionarios()
        {
            InitializeComponent();

            var context = new AppDbContext();
            _funcionarioService = new FuncionarioService(context);
            _funcionarioEmEdicao = null;

            CarregarListaFuncionarios();
        }

        //LÓGICA DE VALIDAÇÃO/MÁSCARA 

        //Impede a digitação de números no campo Nome 
        private void Nome_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Permite letras e espaços. Bloqueia a entrada se contiver um número.
            e.Handled = e.Text.Any(char.IsDigit);
        }

        //Permite apenas números no campo CPF 
        private void Cpf_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Permite apenas dígitos
            e.Handled = !e.Text.All(char.IsDigit);
        }

        // 3. Aplica a Máscara (XXX.XXX.XXX-XX) no campo CPF
        private void Cpf_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox == null || string.IsNullOrWhiteSpace(textBox.Text)) return;
            if (textBox.Tag != null && (bool)textBox.Tag) return; // Se a tag estiver true, ignore (evita loop)

            string text = new string(textBox.Text.Where(char.IsDigit).ToArray());

            if (text.Length > 11)
            {
                text = text.Substring(0, 11);
            }

            // Aplica a máscara:
            if (text.Length > 9)
            {
                text = text.Insert(3, ".").Insert(7, ".").Insert(11, "-");
            }
            else if (text.Length > 6)
            {
                text = text.Insert(3, ".").Insert(7, ".");
            }
            else if (text.Length > 3)
            {
                text = text.Insert(3, ".");
            }

            if (textBox.Text != text)
            {
                textBox.Tag = true; // Define a tag para true para evitar loop
                int caretIndex = textBox.CaretIndex;
                textBox.Text = text;
                textBox.CaretIndex = Math.Min(caretIndex, textBox.Text.Length);
                textBox.Tag = null; // Limpa a tag
            }
        }

        //Lógica de BUSCA, FILTRO E CRUD 

        private void BtnBuscar_Click(object sender, RoutedEventArgs e)
        {
            txtStatus.Text = "";
            txtStatus.Foreground = Brushes.Blue;

            try
            {
                if (!int.TryParse(txtIdBusca.Text, out int idBusca))
                {
                    throw new Exception("ID inválido ou não fornecido para busca.");
                }

                _funcionarioEmEdicao = _funcionarioService.ListarPorId(idBusca);

                if (_funcionarioEmEdicao == null)
                {
                    txtStatus.Text = $"Funcionário ID {idBusca} não encontrado.";
                    return;
                }

                // Preenche o formulário
                txtNome.Text = _funcionarioEmEdicao.Nome;
                txtCpf.Text = _funcionarioEmEdicao.Cpf;

                // Seleciona a Situação correta
                foreach (ComboBoxItem item in cbSituacao.Items)
                {
                    if (item.Tag?.ToString() == _funcionarioEmEdicao.Situacao.ToString())
                    {
                        cbSituacao.SelectedItem = item;
                        break;
                    }
                }

                txtStatus.Text = $"Dados do Funcionário ID {idBusca} carregados para edição.";
                txtStatus.Foreground = Brushes.Blue;
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"ERRO: {ex.Message}";
                txtStatus.Foreground = Brushes.Red;
            }
        }

        private void BtnFiltrar_Click(object sender, RoutedEventArgs e)
        {
            CarregarListaFuncionarios();
        }

        private void CarregarListaFuncionarios()
        {
            txtStatus.Text = "";
            txtStatus.Foreground = Brushes.Red;
            try
            {
                //Obter os parâmetros de filtro da UI
                string termoBusca = txtBuscaNome.Text.ToLower();

                int limite = 0;
                if (cbLimite.SelectedItem != null)
                {
                    string tag = ((ComboBoxItem)cbLimite.SelectedItem).Tag.ToString()!;
                    int.TryParse(tag, out limite);
                }

                //Chamar o serviço que faz a filtragem e limitação
                var listaExibicao = _funcionarioService.ListarResumo(termoBusca, limite);

                //Exibir o resultado final no DataGrid
                DgFuncionarios.ItemsSource = listaExibicao.OrderBy(f => f.Id).ToList();

                txtStatus.Text = $"Lista atualizada. {listaExibicao.Count} registros exibidos.";
                txtStatus.Foreground = Brushes.Green;
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"ERRO ao carregar lista: {ex.Message}";
                txtStatus.Foreground = Brushes.Red;
            }
        }


        private void BtnCadastrar_Click(object sender, RoutedEventArgs e)
        {
            txtStatus.Text = "";
            txtStatus.Foreground = Brushes.Green;

            try
            {
                _funcionarioEmEdicao = null;

                Funcionarios novoFuncionario = new Funcionarios
                {
                    Nome = txtNome.Text!,
                    Cpf = txtCpf.Text!,
                    Situacao = 'A' // Padrão 'A' na criação
                };

                _funcionarioService.Cadastrar(novoFuncionario);

                txtStatus.Text = $"Sucesso! Funcionário {novoFuncionario.Nome} (ID: {novoFuncionario.Id}) cadastrado.";

                // Limpar e recarregar
                txtNome.Text = "";
                txtCpf.Text = "";
                CarregarListaFuncionarios();
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"ERRO: {ex.Message}";
                txtStatus.Foreground = Brushes.Red;
            }
        }

        private void BtnSalvarEdicao_Click(object sender, RoutedEventArgs e)
        {
            txtStatus.Text = "";
            txtStatus.Foreground = Brushes.Green;

            try
            {
                if (_funcionarioEmEdicao == null)
                {
                    throw new Exception("Nenhum funcionário carregado para edição. Use 'Buscar Dados' primeiro.");
                }

                //Obter novos valores da UI
                string novoNome = txtNome.Text!;
                string novoCpf = txtCpf.Text!;

                //Obter a nova situação do ComboBox
                if (cbSituacao.SelectedItem == null)
                {
                    throw new Exception("Situação (Ativo/Inativo) deve ser selecionada.");
                }
                char novaSituacao = char.Parse(((ComboBoxItem)cbSituacao.SelectedItem).Tag.ToString()!);

                //Aplicar as alterações ao objeto
                _funcionarioEmEdicao.Nome = novoNome;
                _funcionarioEmEdicao.Cpf = novoCpf;
                _funcionarioEmEdicao.Situacao = novaSituacao;

                //Salvar via Service
                _funcionarioService.Editar(_funcionarioEmEdicao);

                txtStatus.Text = $"Sucesso! Funcionário {_funcionarioEmEdicao.Id} atualizado para Situação: {_funcionarioEmEdicao.Situacao}.";

                // Limpar e recarregar
                _funcionarioEmEdicao = null;
                txtNome.Text = "";
                txtCpf.Text = "";
                txtIdBusca.Text = "";
                cbSituacao.SelectedIndex = -1;
                CarregarListaFuncionarios();
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"ERRO: {ex.Message}";
                txtStatus.Foreground = Brushes.Red;
            }
        }

        private void DgFuncionarios_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}