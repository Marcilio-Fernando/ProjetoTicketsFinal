﻿using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Models;
using GestorTicketsRefeicao.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace GestorTickets.Desktop.Pages
{
    public partial class PgRelatorios : Page
    {
        private readonly RelatorioService _relatorioService;

        public PgRelatorios()
        {
            InitializeComponent();
            var context = new AppDbContext();
            _relatorioService = new RelatorioService(context);

            txtTotalGeral.Text = "TOTAL GERAL DE TICKETS: 0";
            DgRelatorioDetalhe.Visibility = Visibility.Collapsed;
            txtTituloDetalhe.Text = "Detalhamento por Funcionário (Resumo):";
        }

        //EMISSÃO DE RELATÓRIO RESUMIDO (Geral) 
        private void BtnEmitirResumo_Click(object sender, RoutedEventArgs e)
        {
            txtStatus.Text = "";
            txtTotalGeral.Text = "TOTAL GERAL DE TICKETS: 0";
            txtStatus.Foreground = Brushes.Red;

            try
            {
                if (dpDataInicio.SelectedDate == null || dpDataFim.SelectedDate == null)
                {
                    throw new Exception("Selecione a Data Inicial e a Data Final.");
                }

                DateTime dataInicio = dpDataInicio.SelectedDate.Value.Date;
                DateTime dataFim = dpDataFim.SelectedDate.Value.Date;
                // Lê o estado do Checkbox e define o filtro
                bool incluirInativos = chkIncluirInativos.IsChecked ?? false;

                if (dataInicio > dataFim)
                {
                    throw new Exception("Data Inicial não pode ser maior que a Data Final.");
                }

                dataFim = dataFim.AddHours(23).AddMinutes(59).AddSeconds(59);


                var (totalGeral, detalhes) = _relatorioService.EmitirRelatorio(dataInicio, dataFim, incluirInativos);

                DgRelatorioResumo.Visibility = Visibility.Visible;
                DgRelatorioDetalhe.Visibility = Visibility.Collapsed;
                txtTituloDetalhe.Text = "Detalhamento por Funcionário (Resumo):";

                txtTotalGeral.Text = $"TOTAL GERAL DE TICKETS: {totalGeral}";
                DgRelatorioResumo.ItemsSource = detalhes;

                if (totalGeral == 0)
                {
                    txtStatus.Text = "Nenhum ticket encontrado no período selecionado (considerando o filtro de status).";
                }
                else
                {
                    txtStatus.Text = $"Relatório Resumido emitido com sucesso! Total de {detalhes.Count} funcionários com entregas.";
                    txtStatus.Foreground = Brushes.Green;
                }
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"ERRO: {ex.Message}";
                txtStatus.Foreground = Brushes.Red;
            }
        }

        //EMISSÃO DE RELATÓRIO DETALHADO
        private void BtnEmitirDetalhe_Click(object sender, RoutedEventArgs e)
        {
            txtStatus.Text = "";
            txtTotalGeral.Text = "TOTAL GERAL DE TICKETS: 0";
            txtStatus.Foreground = Brushes.Red;

            try
            {
                if (dpDataInicio.SelectedDate == null || dpDataFim.SelectedDate == null)
                {
                    throw new Exception("Selecione a Data Inicial e a Data Final.");
                }

                DateTime dataInicio = dpDataInicio.SelectedDate.Value.Date;
                DateTime dataFim = dpDataFim.SelectedDate.Value.Date;
                //Lê o estado do Checkbox e define o filtro
                bool incluirInativos = chkIncluirInativos.IsChecked ?? false;

                if (dataInicio > dataFim)
                {
                    throw new Exception("Data Inicial não pode ser maior que a Data Final.");
                }

                dataFim = dataFim.AddHours(23).AddMinutes(59).AddSeconds(59);

             
                var detalhes = _relatorioService.EmitirRelatorioDetalhado(dataInicio, dataFim, incluirInativos);

                DgRelatorioResumo.Visibility = Visibility.Collapsed;
                DgRelatorioDetalhe.Visibility = Visibility.Visible;
                txtTituloDetalhe.Text = "Relatório Detalhado de Entregas:";

                // Cálculo manual para total 
                int totalGeral = 0;
                foreach (var item in detalhes)
                {
                    totalGeral += ((TicketEntregue)item).Quantidade;
                }

                txtTotalGeral.Text = $"TOTAL GERAL DE TICKETS: {totalGeral}";

                DgRelatorioDetalhe.ItemsSource = detalhes;

                if (totalGeral == 0)
                {
                    txtStatus.Text = "Nenhuma entrega detalhada encontrada no período selecionado.";
                }
                else
                {
                    int count = detalhes.Count; 

                    txtStatus.Text = $"Relatório Detalhado emitido com sucesso! Total de {count} entregas.";
                    txtStatus.Foreground = Brushes.Green;
                }
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"ERRO: {ex.Message}";
                txtStatus.Foreground = Brushes.Red;
            }
        }
    }
}