﻿using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Models;
using GestorTicketsRefeicao.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace GestorTickets.Desktop.Pages
{
    public partial class PgTickets : Page
    {
        private readonly TicketEntregueService _ticketService;
        private readonly FuncionarioService _funcionarioService;
        private TicketEntregue? _ticketEmEdicao;

        public PgTickets()
        {
            InitializeComponent();
            var context = new AppDbContext();
            _ticketService = new TicketEntregueService(context);
            _funcionarioService = new FuncionarioService(context);
            _ticketEmEdicao = null;

            CarregarListaTickets();
        }

        //Método para Exibir o Nome do Funcionário ao digitar o ID
        private void TxtFuncionarioId_TextChanged(object sender, TextChangedEventArgs e)
        {
            txtNomeFuncionario.Text = "Buscando...";
            txtNomeFuncionario.Foreground = Brushes.Gray;

            if (int.TryParse(txtFuncionarioId.Text, out int funcionarioId))
            {
              
                var funcionario = _funcionarioService.ListarPorId(funcionarioId);

                if (funcionario != null)
                {
                    txtNomeFuncionario.Text = funcionario.Nome;
                    txtNomeFuncionario.Foreground = Brushes.Blue;
                }
                else
                {
                    txtNomeFuncionario.Text = "Funcionário não encontrado.";
                    txtNomeFuncionario.Foreground = Brushes.Red;
                }
            }
            else if (string.IsNullOrWhiteSpace(txtFuncionarioId.Text))
            {
                txtNomeFuncionario.Text = "Digite o ID para ver o nome.";
                txtNomeFuncionario.Foreground = Brushes.Gray;
            }
            else
            {
                txtNomeFuncionario.Text = "ID inválido.";
                txtNomeFuncionario.Foreground = Brushes.Red;
            }
        }

        //Botão Cadastrar Nova Entrega
        private void BtnCadastrar_Click(object sender, RoutedEventArgs e)
        {
            txtStatusCadastro.Text = "";
            txtStatusCadastro.Foreground = Brushes.Green;

            try
            {
               
                _ticketEmEdicao = null;

                // Validação de campos na seção de cadastro
                if (!int.TryParse(txtFuncionarioId.Text, out int funcionarioId) || funcionarioId <= 0)
                    throw new Exception("ID de Funcionário inválido.");
                if (!int.TryParse(txtQuantidade.Text, out int quantidade) || quantidade <= 0)
                    throw new Exception("Quantidade inválida.");

                TicketEntregue novoTicket = new TicketEntregue
                {
                    FuncionarioId = funcionarioId,
                    Quantidade = quantidade,
                    Situacao = 'A' // RN: Padrão 'A' na criação
                };

                _ticketService.Cadastrar(novoTicket);

                txtStatusCadastro.Text = $"Sucesso! Ticket (ID: {novoTicket.Id}) cadastrado.";

                // Limpar campos de cadastro e recarregar lista
                txtFuncionarioId.Text = "";
                txtQuantidade.Text = "";
                CarregarListaTickets();
            }
            catch (Exception ex)
            {
                txtStatusCadastro.Text = $"ERRO: {ex.Message}";
                txtStatusCadastro.Foreground = Brushes.Red;
            }
        }

        //Lógica de busca para Edição
        private void BtnBuscar_Click(object sender, RoutedEventArgs e)
        {
            txtStatusEdicao.Text = "";
            txtStatusEdicao.Foreground = Brushes.Blue;

            try
            {
                if (!int.TryParse(txtIdBusca.Text, out int idBusca))
                {
                    throw new Exception("ID inválido ou não fornecido para busca.");
                }

                _ticketEmEdicao = _ticketService.ListarTodos().FirstOrDefault(t => t.Id == idBusca);

                if (_ticketEmEdicao == null)
                {
                    txtStatusEdicao.Text = $"Ticket ID {idBusca} não encontrado.";
                    return;
                }

                // Preenche os campos de EDIÇÃO com os dados do ticket encontrado
                // Nota: ID Funcionario não é alterado, apenas exibido para contexto
                txtIdBusca.Text = _ticketEmEdicao.Id.ToString(); 

                // Preenche campos de Edição
                txtNovaQuantidade.Text = _ticketEmEdicao.Quantidade.ToString();

               
                foreach (ComboBoxItem item in cbSituacao.Items)
                {
                    if (item.Tag.ToString() == _ticketEmEdicao.Situacao.ToString())
                    {
                        cbSituacao.SelectedItem = item;
                        break;
                    }
                }

                txtStatusEdicao.Text = $"Dados do Ticket ID {idBusca} carregados. Altere Quantidade e/ou Situação.";
                txtStatusEdicao.Foreground = Brushes.Blue;
            }
            catch (Exception ex)
            {
                txtStatusEdicao.Text = $"ERRO: {ex.Message}";
                txtStatusEdicao.Foreground = Brushes.Red;
            }
        }

        //Botão Salvar Edição/Invalidação
        private void BtnSalvarEdicao_Click(object sender, RoutedEventArgs e)
        {
            txtStatusEdicao.Text = "";
            txtStatusEdicao.Foreground = Brushes.Green;

            try
            {
                if (_ticketEmEdicao == null)
                {
                    throw new Exception("Nenhum ticket carregado para edição. Use 'Buscar Ticket' primeiro.");
                }

                
                if (!int.TryParse(txtNovaQuantidade.Text, out int novaQuantidade) || novaQuantidade <= 0)
                    throw new Exception("Nova Quantidade inválida.");

                if (cbSituacao.SelectedItem == null)
                    throw new Exception("Situação (Ativo/Inativo) deve ser selecionada.");

              
                char novaSituacao = char.Parse(((ComboBoxItem)cbSituacao.SelectedItem).Tag.ToString()!);

              
                _ticketEmEdicao.Quantidade = novaQuantidade;
                _ticketEmEdicao.Situacao = novaSituacao;

                _ticketService.Editar(_ticketEmEdicao);

                txtStatusEdicao.Text = $"Sucesso! Ticket {_ticketEmEdicao.Id} atualizado para Situação: {novaSituacao}.";

                // Limpar e recarregar
                _ticketEmEdicao = null;
                txtIdBusca.Text = "";
                txtNovaQuantidade.Text = "";
                cbSituacao.SelectedIndex = -1;
                CarregarListaTickets();
            }
            catch (Exception ex)
            {
                txtStatusEdicao.Text = $"ERRO: {ex.Message}";
                txtStatusEdicao.Foreground = Brushes.Red;
            }
        }

        //Lógica de Listagem
        private void CarregarListaTickets()
        {
            try
            {
                var lista = _ticketService.ListarTodos();
                DgTickets.ItemsSource = lista;
            }
            catch (Exception ex)
            {
              
                MessageBox.Show($"Erro ao carregar lista de tickets: {ex.Message}", "Erro de Dados", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtIdBusca_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}