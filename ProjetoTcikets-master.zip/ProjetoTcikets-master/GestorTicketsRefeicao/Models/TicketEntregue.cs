﻿namespace GestorTicketsRefeicao.Models
{
    public class TicketEntregue
    {
        public int Id { get; set; }

        public int FuncionarioId { get; set; }

        public Funcionarios Funcionarios { get; set; } = null!;

        public int Quantidade { get; set; }

        public DateTime DataEntrega { get; set; }

        public char Situacao { get; set; }
    }
}