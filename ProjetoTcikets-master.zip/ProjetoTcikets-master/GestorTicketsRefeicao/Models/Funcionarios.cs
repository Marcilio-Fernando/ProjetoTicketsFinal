﻿namespace GestorTicketsRefeicao.Models
{
    public class Funcionarios
    {
        public int Id { get; set; }

        // Propriedades não anuláveis 
        public string Nome { get; set; } = null!;
        public string Cpf { get; set; } = null!;

        public char Situacao { get; set; }
        public DateTime DataAlteracao { get; set; }

        // Propriedade de navegação para EF Core (lista de tickets que este funcionário recebeu)
        public ICollection<TicketEntregue> TicketsEntregues { get; set; } = new List<TicketEntregue>();
    }
}