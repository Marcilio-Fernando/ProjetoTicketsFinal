﻿namespace GestorTicketsRefeicao.Reports
{
    // Objeto usado para transferir o resultado agrupado do Service para a UI
    public class RelatorioFuncionarioDTO
    {
        public string NomeFuncionario { get; set; } = null!;
        public int TotalTicketsEntregues { get; set; }
    }
}