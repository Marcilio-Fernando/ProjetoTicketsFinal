﻿using System;

namespace GestorTicketsRefeicao.Reports
{
    public class FuncionarioResumoDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; } = null!;
        public string Cpf { get; set; } = null!;
        public char Situacao { get; set; }
        public DateTime DataAlteracao { get; set; }
        public int TotalTickets { get; set; } 
    }
}