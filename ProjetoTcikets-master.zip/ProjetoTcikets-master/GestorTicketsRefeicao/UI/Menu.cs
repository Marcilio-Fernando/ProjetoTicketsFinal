﻿using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Models;
using GestorTicketsRefeicao.Reports; // Necessário para listar os resumos
using GestorTicketsRefeicao.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Collections.Generic;

namespace GestorTicketsRefeicao.UI
{
    public class Menu
    {
        private readonly FuncionarioService _funcionarioService;
        private readonly TicketEntregueService _ticketService;
        private readonly RelatorioService _relatorioService;
        private readonly AppDbContext _context;

        public Menu()
        {
            _context = new AppDbContext();
            _funcionarioService = new FuncionarioService(_context);
            _ticketService = new TicketEntregueService(_context);
            _relatorioService = new RelatorioService(_context);
        }

        public void Iniciar()
        {
            bool rodando = true;
            while (rodando)
            {
                Console.Clear();
                Console.WriteLine("=================================================");
                Console.WriteLine("    GERENCIADOR DE TICKETS DE REFEIÇÃO - MENU    ");
                Console.WriteLine("=================================================");
                Console.WriteLine("1. Manutenção de Funcionários (Cadastrar/Editar/Inativar)");
                Console.WriteLine("2. Cadastro de Ticket Entregue (Cadastrar/Editar/Invalidar)");
                Console.WriteLine("3. Emissão de Relatório");
                Console.WriteLine("4. Sair do Sistema");
                Console.WriteLine("=================================================");
                Console.Write("Escolha uma opção: ");

                if (int.TryParse(Console.ReadLine(), out int opcao))
                {
                    try
                    {
                        switch (opcao)
                        {
                            case 1:
                                GerenciarFuncionarios();
                                break;
                            case 2:
                                GerenciarTickets();
                                break;
                            case 3:
                                EmitirRelatorio();
                                break;
                            case 4:
                                rodando = false;
                                Console.WriteLine("\nSistema encerrado. Boa Sorte!");
                                break;
                            default:
                                Console.WriteLine("\nOpção inválida. Pressione qualquer tecla para continuar.");
                                Console.ReadKey();
                                break;
                        }
                    }
                    catch (Microsoft.EntityFrameworkCore.DbUpdateException dbEx)
                    {
                        string innerMessage = dbEx.InnerException?.Message ?? dbEx.Message;
                        Console.WriteLine($"\n[ERRO DE BANCO DE DADOS]: Falha ao salvar no DB. Detalhes: {innerMessage}");
                        Console.WriteLine("Verifique se o CPF já existe ou se há problemas de integridade.");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu principal.");
                        Console.ReadKey();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"\n[ERRO DE VALIDAÇÃO]: {ex.Message}");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu principal.");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("\nEntrada inválida. Pressione qualquer tecla para continuar.");
                    Console.ReadKey();
                }
            }
        }

        //MÉTODOS DE FUNCIONÁRIOS
        private void GerenciarFuncionarios()
        {
            Console.Clear();
            Console.WriteLine("--- Gerenciamento de Funcionários ---");
            Console.WriteLine("1. Cadastrar Novo Funcionário");
            Console.WriteLine("2. Editar/Inativar Funcionário");
            Console.WriteLine("3. Listar Todos");
            Console.WriteLine("4. Voltar");
            Console.Write("Escolha uma opção: ");

            if (int.TryParse(Console.ReadLine(), out int opcao))
            {
                switch (opcao)
                {
                    case 1:
                        CadastrarFuncionario();
                        break;
                    case 2:
                        EditarFuncionario();
                        break;
                    case 3:
                        ListarFuncionarios();
                        break;
                }
            }
            Console.WriteLine("\nPressione qualquer tecla para voltar.");
            Console.ReadKey();
        }

        private void CadastrarFuncionario()
        {
            Console.Clear();
            Console.WriteLine("--- Cadastro de Novo Funcionário ---");

            Console.Write("Nome (Obrigatório): ");
            string nome = Console.ReadLine() ?? string.Empty;

            Console.Write("CPF (Obrigatório, Apenas números): ");
            string cpf = Console.ReadLine() ?? string.Empty;

            Funcionarios novoFuncionario = new Funcionarios
            {
                Nome = nome,
                Cpf = cpf,
                Situacao = 'A'
            };

            _funcionarioService.Cadastrar(novoFuncionario);
            Console.WriteLine($"\nFuncionário {nome} cadastrado com sucesso!");
        }

        private void EditarFuncionario()
        {
            Console.Clear();
            Console.WriteLine("--- Edição/Inativação de Funcionário ---");
            ListarFuncionariosSimples();

            Console.Write("\nDigite o ID do Funcionário para editar: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
                throw new Exception("ID inválido.");

           
            var func = _funcionarioService.ListarPorId(id);

            if (func == null)
            {
                Console.WriteLine("Funcionário não encontrado.");
                return;
            }

            Console.WriteLine($"\nEditando: {func.Nome} (Situação atual: {func.Situacao})");

            Console.Write($"Novo Nome (Deixe em branco para manter '{func.Nome}'): ");
            string novoNome = Console.ReadLine() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(novoNome))
                func.Nome = novoNome;

            Console.Write($"Novo CPF (Deixe em branco para manter '{func.Cpf}'): ");
            string novoCpf = Console.ReadLine() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(novoCpf))
                func.Cpf = novoCpf;

            Console.Write($"Nova Situação (A - Ativo / I - Inativo. Deixe em branco para manter '{func.Situacao}'): ");
            string novaSituacaoStr = Console.ReadLine()?.ToUpper() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(novaSituacaoStr) && char.TryParse(novaSituacaoStr, out char novaSituacao))
            {
                if (novaSituacao != 'A' && novaSituacao != 'I')
                    throw new Exception("Situação deve ser 'A' ou 'I'.");

                func.Situacao = novaSituacao;
                Console.WriteLine($"Situação alterada para: {(novaSituacao == 'A' ? "ATIVO" : "INATIVO")}");
            }

            _funcionarioService.Editar(func);
            Console.WriteLine("\nFuncionário atualizado com sucesso!");
        }

        private void ListarFuncionarios()
        {
            Console.Clear();
            Console.WriteLine("--- Lista de Funcionários ---");

            var lista = _funcionarioService.ListarResumo("", 0);

            if (!lista.Any())
            {
                Console.WriteLine("Nenhum funcionário cadastrado.");
                return;
            }

            foreach (var f in lista)
            {
                Console.WriteLine($"ID: {f.Id} | Nome: {f.Nome.PadRight(30)} | CPF: {f.Cpf} | Situação: {f.Situacao} | Total Tickets: {f.TotalTickets} | Última Alteração: {f.DataAlteracao:dd/MM/yyyy HH:mm}");
            }
        }
        private void ListarFuncionariosSimples()
        {
            Console.WriteLine("--- Funcionários Ativos e Inativos ---");
         
            var lista = _funcionarioService.ListarResumo("", 0);

            if (!lista.Any())
            {
                Console.WriteLine("Nenhum funcionário cadastrado.");
                return;
            }

            foreach (var f in lista)
            {
                Console.WriteLine($"ID: {f.Id} | Nome: {f.Nome.PadRight(30)} | Situação: {f.Situacao}");
            }
        }

        // MÉTODOS DE TICKETS 
        private void GerenciarTickets()
        {
            Console.Clear();
            Console.WriteLine("--- Gerenciamento de Tickets Entregues ---");
            Console.WriteLine("1. Cadastrar Nova Entrega");
            Console.WriteLine("2. Editar/Invalidar Entrega Existente");
            Console.WriteLine("3. Listar Todas as Entregas");
            Console.WriteLine("4. Voltar");
            Console.Write("Escolha uma opção: ");

            if (int.TryParse(Console.ReadLine(), out int opcao))
            {
                switch (opcao)
                {
                    case 1:
                        CadastrarTicket();
                        break;
                    case 2:
                        EditarTicket();
                        break;
                    case 3:
                        ListarTickets();
                        break;
                }
            }
            Console.WriteLine("\nPressione qualquer tecla para voltar.");
            Console.ReadKey();
        }

        private void CadastrarTicket()
        {
            Console.Clear();
            Console.WriteLine("--- Cadastro de Entrega de Ticket ---");
            ListarFuncionariosSimples();

            Console.Write("ID do Funcionário: ");
            if (!int.TryParse(Console.ReadLine(), out int funcionarioId))
                throw new Exception("ID do Funcionário inválido.");

            Console.Write("Quantidade de Tickets: ");
            if (!int.TryParse(Console.ReadLine(), out int quantidade))
                throw new Exception("Quantidade inválida.");

            TicketEntregue novoTicket = new TicketEntregue
            {
                FuncionarioId = funcionarioId,
                Quantidade = quantidade,
                Situacao = 'A'
            };

            _ticketService.Cadastrar(novoTicket);
            Console.WriteLine("\nEntrega de tickets cadastrada com sucesso!");
        }

        private void EditarTicket()
        {
            Console.Clear();
            Console.WriteLine("--- Edição/Invalidação de Entrega ---");
            ListarTickets();

            Console.Write("\nDigite o ID do Ticket para editar/invalidar: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
                throw new Exception("ID inválido.");

            // O ListarTodos() ainda existe na camada TicketService, então esta chamada é válida
            var ticket = _ticketService.ListarTodos().FirstOrDefault(t => t.Id == id);
            if (ticket == null)
            {
                Console.WriteLine("Ticket não encontrado.");
                return;
            }

            Console.WriteLine($"\nEditando Ticket {ticket.Id} (Quantidade atual: {ticket.Quantidade}, Situação atual: {ticket.Situacao})");

            Console.Write($"Nova Quantidade (Deixe em branco para manter '{ticket.Quantidade}'): ");
            string novaQtdStr = Console.ReadLine() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(novaQtdStr) && int.TryParse(novaQtdStr, out int novaQtd))
            {
                if (novaQtd <= 0)
                    throw new Exception("Quantidade deve ser positiva.");
                ticket.Quantidade = novaQtd;
            }

            Console.Write($"Nova Situação (A - Ativo / I - Inativo. Deixe em branco para manter '{ticket.Situacao}'): ");
            string novaSituacaoStr = Console.ReadLine()?.ToUpper() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(novaSituacaoStr) && char.TryParse(novaSituacaoStr, out char novaSituacao))
            {
                if (novaSituacao != 'A' && novaSituacao != 'I')
                    throw new Exception("Situação deve ser 'A' ou 'I'.");

                ticket.Situacao = novaSituacao;
                Console.WriteLine($"Situação alterada para: {(novaSituacao == 'A' ? "ATIVO" : "INATIVO")}");
            }

            _ticketService.Editar(ticket);
            Console.WriteLine("\nEntrega de Ticket atualizada com sucesso!");
        }

        private void ListarTickets()
        {
            Console.WriteLine("\n--- Lista de Entregas de Tickets ---");
            var lista = _ticketService.ListarTodos();

            if (!lista.Any())
            {
                Console.WriteLine("Nenhuma entrega de ticket cadastrada.");
                return;
            }

            foreach (var t in lista)
            {
                string nomeFunc = t.Funcionarios != null ? t.Funcionarios.Nome : "ID Não Encontrado";

                Console.WriteLine($"ID Ticket: {t.Id} | Funcionário: {nomeFunc.PadRight(30)} | Qtd: {t.Quantidade} | Data: {t.DataEntrega:dd/MM/yyyy HH:mm} | Situação: {t.Situacao}");
            }
        }

        // --- MÉTODOS DE RELATÓRIO ---
        private void EmitirRelatorio()
        {
            Console.Clear();
            Console.WriteLine("--- Emissão de Relatório por Período ---");

            Console.Write("Digite a Data Inicial (formato dd/MM/yyyy, ex: 15/10/2024): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime dataInicio))
            {
                Console.WriteLine("Data inicial inválida. Tente o formato dd/MM/yyyy.");
                Console.WriteLine("Pressione qualquer tecla para voltar.");
                Console.ReadKey();
                return;
            }

            Console.Write("Digite a Data Final (formato dd/MM/yyyy): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime dataFim))
            {
                Console.WriteLine("Data final inválida. Tente o formato dd/MM/yyyy.");
                Console.WriteLine("Pressione qualquer tecla para voltar.");
                Console.ReadKey();
                return;
            }

            if (dataInicio > dataFim)
            {
                Console.WriteLine("Data inicial não pode ser maior que a data final.");
                Console.WriteLine("Pressione qualquer tecla para voltar.");
                Console.ReadKey();
                return;
            }


            dataFim = dataFim.Date.AddHours(23).AddMinutes(59).AddSeconds(59);

            // O relatório do console não tem a opção de incluir inativos, então passamos 'false'
            var (totalGeral, detalhes) = _relatorioService.EmitirRelatorio(dataInicio, dataFim, false);

            Console.WriteLine($"\n================== RELATÓRIO {dataInicio:dd/MM/yyyy} a {dataFim:dd/MM/yyyy} ==================");
            Console.WriteLine($"TOTAL GERAL DE TICKETS ENTREGUES (Ativos): {totalGeral}");
            Console.WriteLine("=======================================================================");

            // Exibição dos detalhes
            if (detalhes.Any())
            {
                Console.WriteLine("Detalhamento por Funcionário:");
                Console.WriteLine("-----------------------------------------------------------------------");
                Console.WriteLine("NOME DO FUNCIONÁRIO".PadRight(40) + " | TOTAL DE TICKETS");
                Console.WriteLine("-----------------------------------------------------------------------");
                foreach (var d in detalhes)
                {
                    Console.WriteLine($"{d.NomeFuncionario.PadRight(40)} | {d.TotalTicketsEntregues}");
                }
                Console.WriteLine("-----------------------------------------------------------------------");
            }
            else
            {
                Console.WriteLine("\nNenhum ticket ativo encontrado no período especificado.");
            }

            Console.WriteLine("\n*** FIM DO RELATÓRIO ***");
            Console.WriteLine("Pressione qualquer tecla para voltar ao menu principal.");
            Console.ReadKey();
        }
    }
}