﻿using GestorTicketsRefeicao.Models;
using Microsoft.EntityFrameworkCore;

namespace GestorTicketsRefeicao.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Funcionarios> Funcionarios { get; set; }
        public DbSet<TicketEntregue> TicketsEntregues { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Server=(localdb)\\mssqllocaldb;Database=TicketsDB;Trusted_Connection=True;MultipleActiveResultSets=true"
            );
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Garante que o Id do Funcionário é gerado pelo BD
            modelBuilder.Entity<Funcionarios>()
                .Property(f => f.Id)
                .ValueGeneratedOnAdd();

            // REGRA: CPF deve ser único
            modelBuilder.Entity<Funcionarios>()
                .HasIndex(f => f.Cpf)
                .IsUnique();

            //Garante que o Id do Ticket é gerado pelo BD
            modelBuilder.Entity<TicketEntregue>()
                .Property(t => t.Id)
                .ValueGeneratedOnAdd();

            // Mapeamento da Chave 
            modelBuilder.Entity<TicketEntregue>()
                .HasOne(t => t.Funcionarios)
                .WithMany(f => f.TicketsEntregues)
                .HasForeignKey(t => t.FuncionarioId);
        }
    }
}