﻿using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Models;
using GestorTicketsRefeicao.Reports;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions; 
using Microsoft.EntityFrameworkCore;

namespace GestorTicketsRefeicao.Services
{
    public class FuncionarioService
    {
        private readonly AppDbContext _context;

        public FuncionarioService(AppDbContext context)
        {
            _context = context;
        }

        //VALIDAÇÃO DE CPF (11 DÍGITOS E LÓGICA BÁSICA) 
        private bool IsCpfValido(string cpf)
        {
            // Remove caracteres não numéricos introduzidos
            string numbers = new string(cpf.Where(char.IsDigit).ToArray());

            //Verifica se tem 11 dígitos
            if (numbers.Length != 11)
                return false;

            //Verifica CPFs inválidos conhecidos
            var cpfsInvalidos = new string[]
            {
                "00000000000", "11111111111", "22222222222", "33333333333",
                "44444444444", "55555555555", "66666666666", "77777777777",
                "88888888888", "99999999999"
            };
            if (cpfsInvalidos.Contains(numbers))
                return false;

            //Verifica os dígitos verificadores 
            string tempCpf = numbers.Substring(0, 9);
            int soma = 0;
            int[] multiplicador1 = { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];

            int resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;
            string digito = resto.ToString();
            tempCpf = tempCpf + digito;
            soma = 0;

            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

            resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;
            digito = digito + resto.ToString();

            return numbers.EndsWith(digito);
        }

        // LÓGICA DE CADASTRO 
        public void Cadastrar(Funcionarios funcionario)
        {
            if (string.IsNullOrWhiteSpace(funcionario.Nome))
                throw new Exception("Nome é obrigatório.");
            if (string.IsNullOrWhiteSpace(funcionario.Cpf))
                throw new Exception("CPF é obrigatório.");

            // REGRA:Nome não pode conter dígitos
            if (Regex.IsMatch(funcionario.Nome, @"\d"))
                throw new Exception("O campo Nome não pode conter números. Por favor, insira apenas letras.");

            //REGRA: Validação do CPF
            if (!IsCpfValido(funcionario.Cpf))
                throw new Exception("CPF inválido. Verifique o número e se ele contém 11 dígitos válidos.");

            // Validação de CPF único
            if (_context.Funcionarios.Any(f => f.Cpf == funcionario.Cpf))
                throw new Exception("Já existe um funcionário com este CPF.");

            // Regra de Situação
            if (funcionario.Situacao == 'I')
                throw new Exception("Novo cadastro deve ser iniciado como 'A' (Ativo).");
            if (funcionario.Situacao != 'A' && funcionario.Situacao != 'I')
                throw new Exception("Situação deve ser 'A' para Ativo ou 'I' para Inativo.");

            funcionario.DataAlteracao = DateTime.Now;

            _context.Funcionarios.Add(funcionario);
            _context.SaveChanges();
        }

        //LÓGICA DE EDIÇÃO 
        public void Editar(Funcionarios funcionarioEditado)
        {
            var funcionarioExistente = _context.Funcionarios.Find(funcionarioEditado.Id);

            if (funcionarioExistente == null)
                throw new Exception("Funcionário não encontrado.");

            if (string.IsNullOrWhiteSpace(funcionarioEditado.Nome))
                throw new Exception("Nome é obrigatório.");

            //REGRA: Nome não pode conter dígitos
            if (Regex.IsMatch(funcionarioEditado.Nome, @"\d"))
                throw new Exception("O campo Nome não pode conter números. Por favor, insira apenas letras.");

            //REGRA: Validação do CPF na edição
            if (!IsCpfValido(funcionarioEditado.Cpf))
                throw new Exception("CPF inválido. Verifique o número e se ele contém 11 dígitos válidos.");

            // RN: CPF deve ser único
            if (_context.Funcionarios.Any(f => f.Cpf == funcionarioEditado.Cpf && f.Id != funcionarioEditado.Id))
                throw new Exception("Este CPF já está sendo usado por outro funcionário.");

            // RN: Validação da Situação
            if (funcionarioEditado.Situacao != 'A' && funcionarioEditado.Situacao != 'I')
                throw new Exception("Situação deve ser 'A' para Ativo ou 'I' para Inativo.");

            // Atualiza campos
            funcionarioExistente.Nome = funcionarioEditado.Nome;
            funcionarioExistente.Cpf = funcionarioEditado.Cpf;
            funcionarioExistente.Situacao = funcionarioEditado.Situacao;

            funcionarioExistente.DataAlteracao = DateTime.Now;

            _context.SaveChanges();
        }

        //Listagem /pesquisa
        public List<FuncionarioResumoDTO> ListarResumo(string termoBusca, int limite)
        {
            var consulta = _context.Funcionarios.AsQueryable();

            // 1. Aplica o filtro de busca (Nome ou CPF)
            if (!string.IsNullOrWhiteSpace(termoBusca))
            {
                string termo = termoBusca.ToLower();
                consulta = consulta.Where(f => f.Nome.ToLower().Contains(termo) || f.Cpf.Contains(termo));
            }

            // 2. Projeta para o DTO e calcula o TotalTickets
            var resumo = consulta
                .OrderByDescending(f => f.Id)
                .Select(f => new FuncionarioResumoDTO
                {
                    Id = f.Id,
                    Nome = f.Nome,
                    Cpf = f.Cpf,
                    Situacao = f.Situacao,
                    DataAlteracao = f.DataAlteracao,
                    TotalTickets = f.TicketsEntregues.Sum(t => t.Quantidade)
                });

            // 3. Aplica o Limite (se o limite > 0)
            if (limite > 0)
            {
                resumo = resumo.Take(limite);
            }

            return resumo.OrderBy(f => f.Id).ToList();
        }

        public Funcionarios? ListarPorId(int id)
        {
            return _context.Funcionarios.Find(id);
        }
    }
}