﻿using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Models;
using GestorTicketsRefeicao.Reports;
using Microsoft.EntityFrameworkCore;

namespace GestorTicketsRefeicao.Services
{
    public class RelatorioService
    {
        private readonly AppDbContext _context;

        public RelatorioService(AppDbContext context)
        {
            _context = context;
        }

        // Método para o RELATÓRIO RESUMIDO (Agrupamento - Usado no BtnEmitirResumo)
        public (int TotalGeral, List<RelatorioFuncionarioDTO> Detalhes) EmitirRelatorio(DateTime dataInicio, DateTime dataFim, bool incluirInativos)
        {
            var ticketsNoPeriodo = _context.TicketsEntregues
                .Include(t => t.Funcionarios)
                .Where(t => (incluirInativos ? (t.Situacao == 'A' || t.Situacao == 'I') : (t.Situacao == 'A')) &&
            t.DataEntrega >= dataInicio &&
            t.DataEntrega <= dataFim)
                .ToList();

            int totalGeral = ticketsNoPeriodo.Sum(t => t.Quantidade);

            var detalhes = ticketsNoPeriodo
                .GroupBy(t => t.Funcionarios.Nome)
                .Select(g => new RelatorioFuncionarioDTO
                {
                    NomeFuncionario = g.Key,
                    TotalTicketsEntregues = g.Sum(t => t.Quantidade)
                })
                .OrderByDescending(d => d.TotalTicketsEntregues)
                .ToList();

            return (totalGeral, detalhes);
        }

        // Método para o RELATÓRIO DETALHADO (Lista de Transações - Usado no BtnEmitirDetalhe)
        public List<TicketEntregue> EmitirRelatorioDetalhado(DateTime dataInicio, DateTime dataFim, bool incluirInativos)
        {

            var ticketsNoPeriodo = _context.TicketsEntregues
                .Include(t => t.Funcionarios)
                .Where(t => (incluirInativos ? (t.Situacao == 'A' || t.Situacao == 'I') : (t.Situacao == 'A')) &&
            t.DataEntrega >= dataInicio &&
            t.DataEntrega <= dataFim)
                .OrderBy(t => t.Funcionarios.Nome)
                .ToList();

            return ticketsNoPeriodo;
        }

        internal (object totalGeral, IEnumerable<RelatorioFuncionarioDTO?> detalhes) EmitirRelatorio(DateTime dataInicio, DateTime dataFim)
        {
            throw new NotImplementedException();
        }
    }
}