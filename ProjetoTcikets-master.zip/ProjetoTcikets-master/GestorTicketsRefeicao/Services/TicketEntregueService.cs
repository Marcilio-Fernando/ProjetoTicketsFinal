﻿using GestorTicketsRefeicao.Data;
using GestorTicketsRefeicao.Models;
using Microsoft.EntityFrameworkCore;

namespace GestorTicketsRefeicao.Services
{
    public class TicketEntregueService
    {
        private readonly AppDbContext _context;

        public TicketEntregueService(AppDbContext context)
        {
            _context = context;
        }

        public void Cadastrar(TicketEntregue ticket)
        {
         
            if (ticket.FuncionarioId <= 0)
                throw new Exception("Funcionário é obrigatório.");
            if (ticket.Quantidade <= 0)
                throw new Exception("Quantidade deve ser positiva.");

            // Validação: Funcionário deve existir
            if (!_context.Funcionarios.Any(f => f.Id == ticket.FuncionarioId))
                throw new Exception("O ID de Funcionário informado não existe.");

            // Regra: Situação e Data de Entrega
            if (ticket.Situacao == 'I')
                throw new Exception("Novo cadastro de Ticket deve ser iniciado como 'A' (Ativo).");
            if (ticket.Situacao != 'A')
                throw new Exception("Situação deve ser 'A' para Ativo ou 'I' para Inativo.");

            ticket.DataEntrega = DateTime.Now;

            _context.TicketsEntregues.Add(ticket);
            _context.SaveChanges();
        }

        public void Editar(TicketEntregue ticketEditado)
        {
            var ticketExistente = _context.TicketsEntregues.Find(ticketEditado.Id);

            if (ticketExistente == null)
                throw new Exception("Ticket não encontrado.");

            // Regra: Não permitir alterar o Funcionário
            if (ticketExistente.FuncionarioId != ticketEditado.FuncionarioId)
                throw new Exception("Não é permitido alterar o funcionário de um ticket já entregue.");

            // RN: Validação da Situação
            if (ticketEditado.Situacao != 'A' && ticketEditado.Situacao != 'I')
                throw new Exception("Situação deve ser 'A' para Ativo ou 'I' para Inativo.");

            ticketExistente.Quantidade = ticketEditado.Quantidade;
            ticketExistente.Situacao = ticketEditado.Situacao;

            _context.SaveChanges();
        }

        public List<TicketEntregue> ListarTodos()
        {
         
            return _context.TicketsEntregues
                   .Include(t => t.Funcionarios)
                   .ToList();
        }
    }
}