﻿using GestorTicketsRefeicao.UI;


Menu appMenu = new Menu();
appMenu.Iniciar();

