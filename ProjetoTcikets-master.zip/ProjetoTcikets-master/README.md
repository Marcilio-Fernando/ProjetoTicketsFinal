**Pré-requisitos para a Inicialização**

IDE: **Visual Studio 2022** (com as cargas de trabalho de Desenvolvimento .NET Desktop e Processamento de Dados instaladas).
**Framework: .NET 8 SDK** (ou versão mais recente do .NET 6+). 
**Banco de Dados: SQL Server Express LocalDB.**

**Dependências NuGet Essenciais**
O projeto de lógica (GestorTicketsRefeicao) utiliza os seguintes pacotes NuGet para o acesso a dados:

**Microsoft.EntityFrameworkCore.SqlServer:** Provedor de banco de dados SQL Server.

**Microsoft.EntityFrameworkCore.Design:** Componentes para o design do Entity Framework Core.

**Microsoft.EntityFrameworkCore.Tools:** Ferramentas para o Package Manager Console (Migrations).

.


**Instruções de Inicialização e Configuração do Banco de Dados**

.
Clonar o repositório do GitHub e abrir o arquivo GestorTicketsRefeicao.sln.

Abrir o Console do Gerenciador de Pacotes (PMC).

"No PMC, selecionar o projeto de lógica: GestorTicketsRefeicao."

Executar o comando para criar o BD: **Update-Database**

O projeto de Interface **(GestorTickets.Desktop)** deve estar definido como Projeto de Inicialização. Executar com F5 ou dotnet run.
